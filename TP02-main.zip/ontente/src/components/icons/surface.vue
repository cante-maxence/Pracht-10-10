<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M8.83148 15.5436L3.45631 10.1684C2.8479 9.56002 2.8479 8.4398 3.45631 7.83139L8.83148 2.45621C9.43989 1.84781 10.5601 1.84781 11.1685 2.45621L16.5437 7.83139C17.1521 8.4398 17.1521 9.56002 16.5437 10.1684L11.1685 15.5436C10.5601 16.152 9.43989 16.152 8.83148 15.5436V15.5436Z"
      stroke="#55BC9F"
      stroke-width="1.66667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M2 13.1716L6.36371 17.5353"
      stroke="#55BC9F"
      stroke-width="1.66667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M13.636 17.5353L17.9997 13.1716"
      stroke="#55BC9F"
      stroke-width="1.66667"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>