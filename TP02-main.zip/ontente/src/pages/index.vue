<script setup>
import Card from '../components/card.vue'
</script>
    
<template>
    <h1 class="dark:text-white flex justify-center pt-32 text-2xl">Agence Immobilière</h1>
</template>