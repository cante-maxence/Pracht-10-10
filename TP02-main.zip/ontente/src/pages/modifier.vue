<template>
    <div class="w-96 flex flex-col relative m-auto pt-40 gap-6">
        <RouterLink to="/edit/new">
            <span class="relative p-5 flex justify-center border-[#55BC9F] border-2 dark:text-white dark:hover:border-white dark:hover:text-[#55BC9F] hover:text-[#55BC9F] hover:border-black dark:bg-[#222]">Créer</span>
        </RouterLink>
        <RouterLink to="/edit/0">
            <span class="relative p-5 flex justify-center border-[#55BC9F] border-2 dark:text-white dark:hover:border-white dark:hover:text-[#55BC9F] hover:text-[#55BC9F] hover:border-black dark:bg-[#222]">Modifier première offre</span>
        </RouterLink>
    </div>
</template>