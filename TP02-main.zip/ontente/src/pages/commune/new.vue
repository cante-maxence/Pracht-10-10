<script setup lang="ts">
import FormulaireCommune from "../../components/FormulaireCommune.vue";
</script>

<template>
    <div class="p-2 pt-32 ml-16">
        <FormulaireCommune />
    </div>
</template>