<script setup lang="ts">

import FormulaireOffreMaison from "../../components/FormulaireOffreMaison.vue";

</script>

<template>
    <div>
        <FormulaireOffreMaison></FormulaireOffreMaison>
    </div>
 
</template>