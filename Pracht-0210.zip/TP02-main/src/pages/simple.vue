<script setup lang="ts">
import Card from "../components/card.vue";



const unObjet = {
    price: "1", 
    nom: "Moulins",
    adresse: "1 rue bidon",
    nbrChambre: 4,
    nbrSDB: 1,
    surface:100,
    fav:true,
    image:'src/assets/card.jpg'

}

</script>

<template>
    <div class="grid grid-flow-row-dense grid-cols-[repeat(auto-fit,minmax(420px,420px))] justify-around mb-5 mr-56">
        <Card></Card>
        <Card v-bind="unObjet"></Card>
    </div>
</template>
