<script setup lang="ts">
import FormulaireQuartier from "../../components/FormulaireQuartier.vue";
</script>

<template>
    <div class="p-2">
        <FormulaireQuartier />
        
    </div>
</template>