<script setup>
import Card from '../components/card.vue'
</script>

<template>
  
</template>