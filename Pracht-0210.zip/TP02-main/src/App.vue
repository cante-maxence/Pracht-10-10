<script setup>
import menu_0 from "./components/menu.vue"
</script>

<template>
  <div>
    
    <menu_0 v-if="menu"/>
    
    <Suspense>
      <router-view/>
    </Suspense>
    
  </div>
</template>

<script>
export default {
  data() {
    return {
      menu: true
    }
  },
  components: {

  }
}
</script>